import React from 'react';
import Shop_Sidebar from "./shop-sidebar";
import { FaAngleRight, FaAngleDown, FaShoppingCart, FaEye } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';


class MonthlySubscription extends React.Component {
    handelCart = (name, price, img, id) => {
        let product = {
            name: name,
            img: img,
            price: parseInt(price),
            id: id
        }
        this.addToCart(product)
        console.log('HEllo');
        let names = name + " has been added to your cart."
        toast(names)

        //  window.location.reload(false)
        document.getElementById("abc").innerHTML = this.state.cart.length;

    }

    constructor(props) {
        super(props);

        this.state = {
            records: [],
            recordss: []

        };


        this.getSingleProduct = this.getSingleProduct.bind(this);
    }

    addToCart = (product) => {
        const cart = localStorage.getItem('cart') ?
            JSON.parse(localStorage.getItem('cart')) :
            [];

        // check if duplicates
        const duplicates = cart.filter(cartItem => cartItem.id === product.id);

        // if no duplicates, proceed
        if (duplicates.length === 0) {
            // prep product data
            const productToAdd = {
                ...product,
                count: 1,
            };

            // add product data to cart
            cart.push(productToAdd);

            // add cart to local storage
            localStorage.setItem('cart', JSON.stringify(cart));

        } else {
            const count = duplicates[0].count
            let duplicate = cart.filter(cartItem => cartItem.id !== product.id);
            const productToAdd = {
                ...product,
                count: count + 1,
            };
            duplicate.push(productToAdd)
            localStorage.setItem('cart', JSON.stringify(duplicate));

        }
    }
    componentDidMount() {
        fetch('http://localhost:5000/all_categories')
            .then(response =>
                response.json()
            )

            .then(records => {
                console.log("Wwwwwwwwww", records.allProducts);
                this.setState({
                    records: records.allcategory,
                    recordss: records.allProducts

                })
            })


    }

    getSingleProduct(event) {

    }
    render() {
        return (
            <>
                <div className="container-fluid shop-main">
                    <section className='shop-main-section'>
                        <div className="row">
                            <ToastContainer toastStyle={{ backgroundColor: "green" }} />

                            <div className="col-lg-4 col-md-5">
                                <Shop_Sidebar />
                            </div>
                            <div className="col-lg-8 col-md-7">
                                <section className='breadcrumb-section'>
                                    <div className="row">
                                        <div className="col-lg-8 col-md-12">
                                            <ul class="breadcrumb">
                                                <li><a href="/">Home </a><FaAngleRight /></li>
                                                <li>Products</li>
                                            </ul>
                                        </div>
                                        <div className="col-lg-4 col-md-12">
                                            <div className='short-by'>
                                                <span className='text-light'>SHORT BY:DEFAULT</span><a className='float-right text-light angled'><FaAngleDown /></a>

                                            </div>
                                            <div className="card short-by-li" id='lists'>
                                                <div className="card-body">
                                                    <div>
                                                        <ul>
                                                            <li><a href="#"><span>Default</span></a></li>
                                                            <li><a href="#"><span>Popularity</span></a></li>
                                                            <li><a href="#"><span>Newness</span></a></li>
                                                            <li><a href="#"><span>Low Price</span></a></li>
                                                            <li><a href="#"><span>High Price</span></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section className='shop-product-s'>
                                    <div className="row">
                                        <div className="col-lg-3 col-md-6 text-center">
                                            <a href="/single-product"> <img src="assets/img/uploads/2022/02/healthy-food-2-300x300.png" alt="" />
                                                <h6>Monthly Subscription</h6>
                                                <h4>Premium Monthly Subscription</h4></a>
                                            <h5>₹10000.00</h5>
                                            <div className='product-tool'>
                                                <a href="#" className='tool-button'><FaShoppingCart className='tool' /></a>
                                                <a href="#" className='tool-button'><FaEye className='tool' /></a>
                                            </div>
                                        </div>
                                        <div className="col-lg-3 col-md-6 text-center">
                                            <img src="assets/img/uploads/2022/02/healthy-food-1-300x300.png" alt="" />
                                            <h6>Monthly Subscription</h6>
                                            <h4>Standard Monthly Subscription</h4>
                                            <h5>₹7500.00</h5>
                                            <div className='product-tool'>
                                                <a href="#" className='tool-button'><FaShoppingCart className='tool' /></a>
                                                <a href="#" className='tool-button'><FaEye className='tool' /></a>
                                            </div>
                                        </div>
                                        <div className="col-lg-3 col-md-6 text-center">
                                            <img src="assets/img/uploads/2022/02/healthy-food-300x300.png" alt="" />
                                            <h6>Monthly Subscription</h6>
                                            <h4>Basic Monthly Subscription</h4>
                                            <h5>₹5000.00</h5>
                                            <div className='product-tool'>
                                                <a href="#" className='tool-button'><FaShoppingCart className='tool' /></a>
                                                <a href="#" className='tool-button'><FaEye className='tool' /></a>
                                            </div>
                                        </div>
                                      
                                    </div>
                                    
                                   
                                 
                                </section>
                            </div>
                        </div>
                    </section>
                </div>
            </>
        )
    }
}
export default MonthlySubscription